import io
import pdfplumber
import re

# Sumy imports
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lex_rank import LexRankSummarizer
from sumy.nlp.stemmers import Stemmer
from sumy.utils import get_stop_words

def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    """Extract text from PDF bytes using pdfplumber."""
    text_pages = []
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for page in pdf.pages:
                try:
                    page_text = page.extract_text() or ''
                except Exception:
                    page_text = ''
                if page_text:
                    text_pages.append(page_text)
    except Exception as e:
        raise RuntimeError(f'Failed to read PDF: {e}')
    text = '\n'.join(text_pages)
    # Basic cleanup
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def summarize_text(text: str, sentences_count: int = 3, language: str = 'english') -> str:
    """Summarize using Sumy's LexRank (extractive summarization)."""
    if not text or len(text.split()) < 50:
        # Too short to summarize reliably
        return text
    parser = PlaintextParser.from_string(text, Tokenizer(language))
    stemmer = Stemmer(language)
    summarizer = LexRankSummarizer(stemmer)
    summarizer.stop_words = get_stop_words(language)
    summary_sentences = summarizer(parser.document, sentences_count)
    summary = ' '.join(str(s) for s in summary_sentences)
    return summary
