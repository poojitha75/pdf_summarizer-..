import streamlit as st
from summarizer import extract_text_from_pdf, summarize_text
import nltk

# Ensure punkt is available or show instructions
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    st.warning('NLTK punkt tokenizer not found. If summarization fails, run: python -m nltk.downloader punkt')

st.set_page_config(page_title='PDF Summarizer', layout='centered')

st.title('📄 PDF Summarizer')
st.markdown('Upload a PDF and get a concise extractive summary. Uses pdfplumber + Sumy (LexRank).')

uploaded = st.file_uploader('Upload PDF file', type=['pdf'])

sentences = st.slider('Summary length (sentences)', min_value=1, max_value=10, value=3)

if uploaded is not None:
    try:
        raw_text = extract_text_from_pdf(uploaded.read())
        if not raw_text.strip():
            st.error('No extractable text found in the uploaded PDF. It might be scanned or image-only. Try OCR or upload a text-based PDF.')
        else:
            st.subheader('Extracted text (first 2,000 characters)')
            st.write(raw_text[:2000] + ('...' if len(raw_text) > 2000 else ''))
            if st.button('Generate Summary'):
                with st.spinner('Summarizing...'):
                    summary = summarize_text(raw_text, sentences)
                st.subheader('Summary')
                st.write(summary)
                st.download_button('Download summary (.txt)', summary, file_name='summary.txt')
    except Exception as e:
        st.error(f'Error processing PDF: {e}')
else:
    st.info('Upload a PDF to get started.')
