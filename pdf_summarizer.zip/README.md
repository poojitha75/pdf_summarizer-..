# PDF Summarizer (Streamlit)

## What this is
A small extractive PDF summarizer using `pdfplumber` for text extraction and `sumy` (LexRank) for summarization.
The app uses Streamlit for a simple UI. This is intended as an interview-ready demo you can run locally.

## Setup (recommended)
1. Create a Python virtual environment (optional, but recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate   # on Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. NLTK data: The app tries to detect the `punkt` tokenizer. If you see a warning, run:
   ```bash
   python -m nltk.downloader punkt
   ```
4. Run the app:
   ```bash
   streamlit run app.py
   ```

## Files
- `app.py` - Streamlit app (UI + glue)
- `summarizer.py` - PDF extraction + summarization logic
- `requirements.txt` - dependencies
- `README.md` - this file

## Notes / Troubleshooting
- If a PDF is scanned (image-only), `pdfplumber` may not extract text. Use OCR (Tesseract) preprocess step for scanned PDFs.
- The summarizer is extractive (picks sentences). For abstractive summaries, consider Hugging Face transformers (requires internet and more RAM).
